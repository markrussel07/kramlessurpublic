module PracticalHelper
end
