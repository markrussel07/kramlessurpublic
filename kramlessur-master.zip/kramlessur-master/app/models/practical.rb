class Practical < ApplicationRecord
end
