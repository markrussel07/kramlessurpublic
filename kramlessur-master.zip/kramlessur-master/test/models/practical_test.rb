require 'test_helper'

class PracticalTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
